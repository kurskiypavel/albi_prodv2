CREATE TRIGGER new_booking_admin
AFTER INSERT ON `notifications-booking`
FOR EACH ROW
  BEGIN

IF (NEW.canceled ='1') THEN

	INSERT INTO `notifications-booking_admin` (user_name,user_phone,owner,program, program_id, schedule,comment,event_id,canceled) 
    select users.first_name,users.phone,events.student,programs.title, events.program,  programs.schedule,events.comment, events.id,1
from events,programs,users where events.id=NEW.event_id and programs.id=NEW.program_id and users.id=NEW.owner;

ELSEIF (NEW.program IS NULL) THEN
		INSERT INTO `notifications-booking_admin` (date,time,comment,user_name,user_phone,event_id,repeatble,owner,confirmed) 
		
		select events.date,events.time,events.comment, users.`first_name`,users.`phone`, events.id,events.repeatble,events.student,events.confirmed
from events join users on users.id = events.student where events.id=NEW.event_id;

      ELSE
			INSERT INTO `notifications-booking_admin` (user_name,user_phone,owner,program, program_id, schedule,comment,event_id,confirmed) 
    select users.first_name,users.phone,events.student,programs.title, events.program,  programs.schedule,events.comment, events.id,events.confirmed
from events,programs,users where events.id=NEW.event_id and programs.id=NEW.program_id and users.id=NEW.owner;
      END IF;
      
  END;
