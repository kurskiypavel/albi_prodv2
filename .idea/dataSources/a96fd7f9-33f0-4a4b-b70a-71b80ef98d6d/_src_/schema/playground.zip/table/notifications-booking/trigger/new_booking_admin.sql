CREATE TRIGGER new_booking_admin
AFTER INSERT ON `notifications-booking`
FOR EACH ROW
  BEGIN

/*Cancel*/
IF (NEW.canceled ='1' AND NEW.program IS NULL) THEN

	INSERT INTO `notifications-booking_admin` (date,time,user_name,user_phone,event_id,canceled) 
    select events.date, events.time, users.`first_name`,users.`phone`,events.id,1
	from events,users where events.id=NEW.event_id and users.id=NEW.owner;

ELSEIF (NEW.canceled ='1' AND NEW.program IS NOT NULL) THEN

	INSERT INTO `notifications-booking_admin` (user_name,user_phone,program, program_id, schedule,event_id,canceled) 
    select users.first_name,users.phone,programs.title, events.program,  programs.schedule, events.id,1
	from events,programs,users where events.id=NEW.event_id and programs.id=NEW.program_id and users.id=NEW.owner;

/*Update + New - Private*/
ELSEIF (NEW.program IS NULL AND NEW.confirmed IS NULL) THEN
	INSERT INTO `notifications-booking_admin` (date,time,old_date,old_time,comment,user_name,user_phone,event_id,repeatble,`change`) 	
	select NEW.date,NEW.time,NEW.`old_date`,NEW.`old_time`,events.comment, users.`first_name`,users.`phone`, events.id,events.repeatble,NEW.change
	from events join users on users.id = events.student where events.id=NEW.event_id;

/*Update + New - Group*/
ELSEIF (NEW.program IS NOT NULL AND NEW.confirmed IS NULL) THEN
	INSERT INTO `notifications-booking_admin` (user_name,user_phone,program, program_id, schedule,comment,event_id,`change`) 
    select users.first_name,users.phone,programs.title, events.program,  programs.schedule,events.comment,events.id,NEW.change
	from events,programs,users where events.id=NEW.event_id and programs.id=NEW.program_id and users.id=NEW.owner;
END IF;
      
END;
