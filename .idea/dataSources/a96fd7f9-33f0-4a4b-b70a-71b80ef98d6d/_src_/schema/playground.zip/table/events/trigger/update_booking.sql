CREATE TRIGGER update_booking
AFTER UPDATE ON events
FOR EACH ROW
  BEGIN

	/*for admin confirmation trigger in notif-booking table*/
	

	
/*Update - Group*/
IF (NEW.program IS NOT NULL) THEN
	
	INSERT INTO `notifications-booking_admin` (user_name,user_phone,owner,program, program_id, schedule,comment,event_id) 
    select users.first_name,users.phone,events.student,programs.title, events.program,  programs.schedule,events.comment, 	events.id
	from events,programs,users where events.id=NEW.id and programs.id=NEW.program and users.id=NEW.student;

END IF;
      
      
END;
