CREATE TRIGGER new_booking
AFTER INSERT ON events
FOR EACH ROW
  BEGIN
/* new private*/
IF (NEW.program IS NULL) THEN
		INSERT INTO `notifications-booking` (date,time,owner,event_id,repeatble) 
    select date, time, student, id,repeatble
from events where id = NEW.id;
      ELSE
      /*new group*/
			INSERT INTO `notifications-booking` (owner,program,schedule,program_id,event_id) 
			select events.student, programs.title, programs.schedule, events.program, events.id
from events join programs on programs.id = events.program where events.id=NEW.id;
      END IF;
      
  END;
