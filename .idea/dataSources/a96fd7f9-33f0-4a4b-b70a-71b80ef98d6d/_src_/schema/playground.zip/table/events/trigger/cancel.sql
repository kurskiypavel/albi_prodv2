CREATE TRIGGER cancel
BEFORE DELETE ON events
FOR EACH ROW
  BEGIN


	/*UPDATE `notifications-booking` SET `canceled` = '1'
where `event_id`=OLD.id;
		UPDATE `notifications-booking_admin` SET `canceled` = '1'
where `event_id`=OLD.id;*/

	
	
	IF (OLD.program IS NULL) THEN
		INSERT INTO `notifications-booking` (date,time,owner,event_id,repeatble,canceled) 
    select date, time, student, id,repeatble,'1'
from events where id = OLD.id;
      ELSE
			INSERT INTO `notifications-booking` (owner,program,schedule,program_id,event_id,canceled) 
	select events.student, programs.title, programs.schedule, events.program, events.id, '1'
	from events join programs on programs.id = events.program where events.id=OLD.id;
      END IF;
      
END;
