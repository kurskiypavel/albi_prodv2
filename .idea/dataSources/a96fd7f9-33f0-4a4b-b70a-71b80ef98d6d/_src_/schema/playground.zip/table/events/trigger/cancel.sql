CREATE TRIGGER cancel
BEFORE DELETE ON events
FOR EACH ROW
  BEGIN


	/*UPDATE `notifications-booking` SET `canceled` = '1'
where `event_id`=OLD.id;
		UPDATE `notifications-booking_admin` SET `canceled` = '1'
where `event_id`=OLD.id;*/


	INSERT INTO `notifications-booking` (date,time,owner,event_id,repeatble,canceled) 
    select date, time, student, id,repeatble,1
	from events where id = OLD.id;
      
END;
