CREATE TRIGGER private_update
BEFORE UPDATE ON events
FOR EACH ROW
  BEGIN

/*Update - Private*/
IF (NEW.program IS NULL AND NEW.confirmed IS NULL) THEN
	INSERT INTO `notifications-booking` (date,time,old_date,old_time,owner,event_id,repeatble,`change`) 
    select NEW.date, NEW.time,OLD.date,OLD.time, student, id,repeatble,'1'
	from events where id = NEW.id;

END IF;	
END;
