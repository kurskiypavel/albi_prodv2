CREATE TRIGGER welcome_message
AFTER INSERT ON users
FOR EACH ROW
  BEGIN
/* welcome message for new user*/

INSERT INTO `messages` (conversation,message,author) 
    select id,'Привет, друг! Теперь выбери практику и вперед! Встретимся на коврике)', '1'
from users where id = NEW.id;
          
END;
